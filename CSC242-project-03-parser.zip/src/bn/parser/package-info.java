/**
 * Parsers for BIF and XMLBIF file formats for Bayesian networks.
 */
package bn.parser;